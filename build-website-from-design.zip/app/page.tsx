"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { HistoryTable } from "@/components/dashboard/history-table"
import { WebsiteTypeModal } from "@/components/wizard/website-type-modal"
import { Wizard } from "@/components/wizard/wizard"
import type { Website, WebsiteType } from "@/lib/types"

// Sample data
const sampleWebsites: Website[] = [
  {
    id: "1",
    title: "Your Website Title Here",
    price: "₹9",
    sale: "0 ↑",
    revenue: "₹0",
    status: "Published",
  },
  {
    id: "2",
    title: "New Feature Announcement",
    price: "₹900",
    sale: "2 ↑",
    revenue: "₹100",
    status: "Active",
  },
  {
    id: "3",
    title: "User Feedback Report",
    price: "₹50",
    sale: "-",
    revenue: "₹777",
    status: "Pending",
  },
]

export default function DashboardPage() {
  const [showTypeModal, setShowTypeModal] = useState(false)
  const [selectedType, setSelectedType] = useState<WebsiteType | null>(null)
  const [showWizard, setShowWizard] = useState(false)

  const handleCreateWebsite = () => {
    setShowTypeModal(true)
  }

  const handleSelectType = (type: WebsiteType) => {
    setSelectedType(type)
    setShowTypeModal(false)
    setShowWizard(true)
  }

  const handleCloseWizard = () => {
    setShowWizard(false)
    setSelectedType(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header onCreateWebsite={handleCreateWebsite} />
      <HistoryTable websites={sampleWebsites} />

      {/* Website Type Selection Modal */}
      <WebsiteTypeModal
        open={showTypeModal}
        onOpenChange={setShowTypeModal}
        onSelect={handleSelectType}
      />

      {/* Wizard */}
      {showWizard && selectedType && (
        <Wizard websiteType={selectedType} onClose={handleCloseWizard} />
      )}
    </div>
  )
}
