"use client"

import { MoreVertical, Filter, ArrowUpDown, FileDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import type { Website } from "@/lib/types"

interface HistoryTableProps {
  websites: Website[]
}

export function HistoryTable({ websites }: HistoryTableProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Published":
        return "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
      case "Active":
        return "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
      case "Pending":
        return "bg-amber-100 text-amber-700 hover:bg-amber-100"
      case "Draft":
        return "bg-muted text-muted-foreground hover:bg-muted"
      default:
        return "bg-muted text-muted-foreground hover:bg-muted"
    }
  }

  return (
    <div className="p-6">
      {/* Table Controls */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">History</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <Filter className="size-4" />
            Filters
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <ArrowUpDown className="size-4" />
            Sort
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <FileDown className="size-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search..."
          className="w-64 px-3 py-2 text-sm border rounded-md bg-background"
        />
      </div>

      {/* Table */}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">
              <input type="checkbox" className="rounded" />
            </TableHead>
            <TableHead>Website</TableHead>
            <TableHead>Price</TableHead>
            <TableHead>Sale</TableHead>
            <TableHead>Revenue</TableHead>
            <TableHead>More</TableHead>
            <TableHead className="w-12"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {websites.map((website) => (
            <TableRow key={website.id}>
              <TableCell>
                <input type="checkbox" className="rounded" />
              </TableCell>
              <TableCell className="font-medium">{website.title}</TableCell>
              <TableCell>{website.price}</TableCell>
              <TableCell>{website.sale}</TableCell>
              <TableCell>{website.revenue}</TableCell>
              <TableCell>
                <Badge className={getStatusColor(website.status)} variant="secondary">
                  {website.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Button variant="ghost" size="icon-sm">
                  <MoreVertical className="size-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
